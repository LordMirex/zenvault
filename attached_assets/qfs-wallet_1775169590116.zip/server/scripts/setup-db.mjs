import { createPool } from 'mysql2/promise';
import { hashSecret } from '../auth.mjs';
import { config } from '../config.mjs';
import {
  seedKycCases,
  seedSettings,
  seedTransactions,
  seedUsers,
} from '../data/seed.mjs';

const stringify = (value) => JSON.stringify(value ?? []);

const createConnection = async (database) =>
  createPool({
    host: config.dbHost,
    port: config.dbPort,
    user: config.dbUser,
    password: config.dbPassword,
    database,
    connectionLimit: 1,
    waitForConnections: true,
  });

const setup = async () => {
  const root = await createConnection(undefined);
  await root.query(`CREATE DATABASE IF NOT EXISTS \`${config.dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci`);
  await root.end();

  const db = await createConnection(config.dbName);

  const ddl = [
    'DROP TABLE IF EXISTS settings',
    'DROP TABLE IF EXISTS kyc_cases',
    'DROP TABLE IF EXISTS transactions',
    'DROP TABLE IF EXISTS users',
    `CREATE TABLE users (
      id INT PRIMARY KEY,
      role VARCHAR(16) NOT NULL,
      name VARCHAR(120) NOT NULL,
      email VARCHAR(190) NOT NULL UNIQUE,
      phone VARCHAR(40) DEFAULT '',
      city VARCHAR(80) DEFAULT '',
      uuid VARCHAR(80) DEFAULT '',
      country VARCHAR(80) DEFAULT '',
      desk_label VARCHAR(120) DEFAULT '',
      tier VARCHAR(40) DEFAULT '',
      status VARCHAR(40) DEFAULT '',
      kyc_status VARCHAR(40) DEFAULT '',
      risk_level VARCHAR(40) DEFAULT '',
      portfolio_usd DECIMAL(18,2) DEFAULT 0,
      available_usd DECIMAL(18,2) DEFAULT 0,
      portfolio_change_usd DECIMAL(18,2) DEFAULT 0,
      portfolio_change_pct DECIMAL(10,2) DEFAULT 0,
      wallet_connected TINYINT(1) DEFAULT 1,
      plan_name VARCHAR(120) DEFAULT '',
      last_seen VARCHAR(120) DEFAULT '',
      note TEXT,
      password_hash VARCHAR(255) NOT NULL,
      passcode_hash VARCHAR(255) NOT NULL,
      holdings_json LONGTEXT NOT NULL,
      cards_json LONGTEXT NOT NULL,
      deposit_activity_json LONGTEXT NOT NULL,
      withdrawal_activity_json LONGTEXT NOT NULL,
      notifications_json LONGTEXT NOT NULL,
      address_book_json LONGTEXT NOT NULL,
      referrals_json LONGTEXT NOT NULL,
      sessions_json LONGTEXT NOT NULL,
      kyc_checklist_json LONGTEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE transactions (
      id VARCHAR(40) PRIMARY KEY,
      user_id INT NOT NULL,
      type VARCHAR(40) NOT NULL,
      asset VARCHAR(80) NOT NULL,
      amount VARCHAR(120) NOT NULL,
      channel VARCHAR(120) DEFAULT '',
      destination VARCHAR(190) DEFAULT '',
      status VARCHAR(40) NOT NULL,
      created_at_label VARCHAR(120) DEFAULT '',
      from_asset VARCHAR(80) DEFAULT '',
      to_asset VARCHAR(80) DEFAULT '',
      which_crypto VARCHAR(80) DEFAULT '',
      network_fee VARCHAR(80) DEFAULT '',
      rate VARCHAR(80) DEFAULT ''
    )`,
    `CREATE TABLE kyc_cases (
      id VARCHAR(40) PRIMARY KEY,
      user_id INT NOT NULL,
      document_type VARCHAR(190) NOT NULL,
      submitted_at_label VARCHAR(120) DEFAULT '',
      country VARCHAR(80) DEFAULT '',
      risk_level VARCHAR(40) DEFAULT '',
      status VARCHAR(40) DEFAULT '',
      note TEXT
    )`,
    `CREATE TABLE settings (
      setting_key VARCHAR(80) PRIMARY KEY,
      setting_value LONGTEXT NOT NULL,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,
  ];

  for (const statement of ddl) {
    await db.query(statement);
  }

  const userSql = `
    INSERT INTO users (
      id, role, name, email, phone, city, uuid, country, desk_label, tier, status, kyc_status, risk_level,
      portfolio_usd, available_usd, portfolio_change_usd, portfolio_change_pct, wallet_connected, plan_name, last_seen, note,
      password_hash, passcode_hash, holdings_json, cards_json, deposit_activity_json, withdrawal_activity_json,
      notifications_json, address_book_json, referrals_json, sessions_json, kyc_checklist_json
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  for (const user of seedUsers) {
    await db.execute(userSql, [
      user.id,
      user.role,
      user.name,
      user.email,
      user.phone,
      user.city,
      user.uuid,
      user.country,
      user.deskLabel,
      user.tier,
      user.status,
      user.kycStatus,
      user.riskLevel,
      user.portfolioUsd,
      user.availableUsd,
      user.portfolioChangeUsd,
      user.portfolioChangePct,
      user.walletConnected ? 1 : 0,
      user.plan,
      user.lastSeen,
      user.note,
      await hashSecret(user.password),
      await hashSecret(user.passcode),
      stringify(user.holdings),
      stringify(user.cards),
      stringify(user.depositActivity),
      stringify(user.withdrawalActivity),
      stringify(user.notifications),
      stringify(user.addressBook),
      stringify(user.referrals),
      stringify(user.recentSessions),
      stringify(user.kycChecklist),
    ]);
  }

  for (const transaction of seedTransactions) {
    await db.execute(
      `INSERT INTO transactions (id, user_id, type, asset, amount, channel, destination, status, created_at_label, from_asset, to_asset, which_crypto, network_fee, rate)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [transaction.id, transaction.userId, transaction.type, transaction.asset, transaction.amount, transaction.channel, transaction.destination, transaction.status, transaction.createdAt, transaction.fromAsset, transaction.toAsset, transaction.whichCrypto, transaction.networkFee, transaction.rate],
    );
  }

  for (const item of seedKycCases) {
    await db.execute(
      `INSERT INTO kyc_cases (id, user_id, document_type, submitted_at_label, country, risk_level, status, note)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [item.id, item.userId, item.documentType, item.submittedAt, item.country, item.riskLevel, item.status, item.note],
    );
  }

  for (const [settingKey, settingValue] of Object.entries(seedSettings)) {
    await db.execute(`INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)`, [settingKey, JSON.stringify(settingValue)]);
  }

  await db.end();
  console.log(`Database ${config.dbName} created and seeded successfully.`);
};

setup().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
