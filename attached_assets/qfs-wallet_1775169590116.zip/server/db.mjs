import mysql from 'mysql2/promise';
import { config } from './config.mjs';

let pool;

export const getPool = () => {
  if (!pool) {
    pool = mysql.createPool({
      host: config.dbHost,
      port: config.dbPort,
      user: config.dbUser,
      password: config.dbPassword,
      database: config.dbName,
      connectionLimit: 10,
      waitForConnections: true,
      namedPlaceholders: true,
    });
  }

  return pool;
};

export const query = async (sql, params = {}) => {
  const [rows] = await getPool().execute(sql, params);
  return rows;
};

export const queryOne = async (sql, params = {}) => {
  const rows = await query(sql, params);
  return rows[0] ?? null;
};

export const closePool = async () => {
  if (pool) {
    await pool.end();
    pool = undefined;
  }
};
