# QFS Live System Audit

Captured on `2026-03-30` from `https://qfs.developerplug.com` using the provided user and admin accounts.

This document is the reference spec for rebuilding the project as a clean fullstack application. It is based on live navigation, saved HTML, and full-page screenshots, not on memory.

## Evidence Collected

- Live capture folders:
  - `_workspace/references/_scraper/live-user-core`
  - `_workspace/references/_scraper/live-user-flows-a`
  - `_workspace/references/_scraper/live-user-flows-b`
  - `_workspace/references/_scraper/live-user-flows-c`
  - `_workspace/references/_scraper/live-user-assets`
  - `_workspace/references/_scraper/live-admin-a`
  - `_workspace/references/_scraper/live-admin-b`
  - `_workspace/references/_scraper/live-admin-c`
  - `_workspace/references/_scraper/live-admin-d`
- Total saved evidence: `53` HTML files and `53` screenshots.
- Recovered clone material already in workspace:
  - `_workspace/references/_scraper/raw_html` for user-side recovered pages
  - `_workspace/references/_scraper/admin-clone/recovered-admin` for admin recovered pages
- Important workspace note: the original Laravel source is not present in this workspace. What we have locally is:
  - the current React app in `qfs-wallet`
  - recovered HTML/screenshots in `_workspace/references/_scraper`

## 1. Authentication and Role Routing

1. All users start at `/login` with email and password.
2. Successful login does not enter the app directly. The system redirects to `/passcode`.
3. `/passcode` expects a six-digit passcode for both user and admin accounts.
4. After passcode verification:
   - normal user lands on `/dashboard`
   - admin lands on `/admin/dashboard`
5. User logout is exposed from the settings area.
6. Admin logout is exposed in the top-right header.
7. Sensitive user routes can trigger another passcode gate. This was observed on `/crypto/details/btc/native`, which opened a second "Security Check" screen.

## 2. User Application Behavior

### Main navigation

Visible user sidebar items:

- `Home`
- `Swap`
- `Deposit`
- `Withdraw`
- `Bots`
- `Cards`
- `Referrals`
- `Settings`
- `Manage Crypto`
- `Crypto Address`
- `Notification`

Important user routes confirmed live:

- `/dashboard`
- `/buy`
- `/swap`
- `/bots`
- `/card`
- `/referral`
- `/settings`
- `/profile`
- `/kyc`
- `/crypto/manage`
- `/crypto/address`
- `/notifications`
- `/send/payid`
- `/send/external`
- `/send/payid/{symbol}/{network}`
- `/send/external/{symbol}/{network}`
- `/receive/payid`
- `/receive/external`
- `/receive/payid/{symbol}/{network}`
- `/receive/external/{symbol}/{network}`
- `/crypto/details/{symbol}/{network}`

### Dashboard

Route: `/dashboard`

Behavior:

- Shows the logged-in username near the top.
- Shows one large portfolio total in USD.
- Provides four primary quick actions:
  - `Send`
  - `Receive`
  - `Buy`
  - `Swap`
- Shows a green `Wallet Connected` state banner.
- Shows a long asset list with:
  - coin icon
  - symbol
  - price
  - percentage move
  - crypto balance
  - fiat value

Backend implications:

- user total portfolio value
- holdings list
- per-holding price snapshot
- wallet connection state

### Buy Crypto

Route: `/buy`

Behavior:

- Search input for coin name.
- Network filter chips such as `All Networks`, `TRC20`, `ERC20`, `BNB`.
- Asset list is similar to the dashboard list.
- This screen behaves like an asset picker rather than a fiat checkout flow.

Backend implications:

- searchable asset catalog
- network-aware asset grouping
- balances alongside market data

### Swap

Route: `/swap`

Behavior:

- Two panels: `From` and `To`.
- Each side requires asset selection.
- Quick percentage buttons: `25%`, `50%`, `75%`, `100%`.
- Primary action starts as `Select currencies`.
- Saved HTML contains a `Swap Successful!` state/modal.

Backend implications:

- supported swap pairs
- estimated quote
- execution result
- transaction creation and notification

### Bots

Route: `/bots`

Behavior:

- Shows a hero block with `Subscribe Now`.
- Summary cards include:
  - active subscriptions
  - total investment
  - win rate
  - total profit
- Main table is `Bot History`.
- Table columns:
  - bot name
  - amount
  - status
  - result
  - profit/loss

Backend implications:

- bot catalog
- user subscriptions
- user bot trade history

### Cards

Route: `/card`

Behavior:

- Shows a virtual card surface.
- Current live user card state is `INACTIVE`.
- Primary visible CTA is `Activate Card`.
- Saved HTML includes additional card management controls and form fields:
  - card holder data
  - CVV
  - expiry date
  - billing address
  - ZIP code

Backend implications:

- user cards
- card status
- card activation
- card funding history

### Referrals

Route: `/referral`

Behavior:

- Summary cards for:
  - total referrals
  - this month
- Displays the user referral link with copy action.
- Shows recent referrals list or empty state.

Backend implications:

- unique referral code/link
- referral registrations
- referral reward ledger

### Settings

Route: `/settings`

Behavior:

- This is a menu screen, not a single form.
- Links to:
  - `Manage Crypto`
  - `Crypto Address`
  - `Referrals`
  - `Notification`
  - `Account verification`
  - `Password settings`
  - `Logout`

Backend implications:

- settings is a navigation hub
- each action points to a dedicated feature screen

### Manage Crypto

Route: `/crypto/manage`

Behavior:

- Lists supported assets and networks.
- Each asset has a toggle switch.
- Live screen shows the toggles enabled for multiple assets.

Backend implications:

- user wallet visibility preferences
- enabled/disabled asset switches per user

### Crypto Address

Route: `/crypto/address`

Behavior:

- Search box for coin name.
- Network filter chips.
- Shows wallet addresses per supported network.

Backend implications:

- per-user or global deposit addresses
- network-specific address storage

### Notifications

Route: `/notifications`

Behavior:

- Paginated notification feed.
- `Mark All Read` action.
- Live notifications include swap events, completed transactions, and card funding.

Backend implications:

- notification table
- read/unread state
- generated event messages

### Profile / Security

Route: `/profile`

Behavior:

- Security settings form, not a profile-avatar form.
- Fields:
  - six-digit passcode
  - current password
  - new password
  - confirm new password
- Main action: `Change Password`

Backend implications:

- password update
- passcode update
- current-password verification

### KYC

Route: `/kyc`

Behavior:

- Current user is verified, so live screen shows a success banner and verification timestamp.
- Saved HTML still contains upload controls and submit action for the unverified state.
- KYC document inputs detected:
  - `front_id`
  - `back_id`
  - `proof_of_residence`
- Submit action: `Submit for Verification`

Backend implications:

- KYC submission status
- three document uploads
- approval/rejection workflow

### Send / Withdraw flows

Hub routes:

- `/send/payid`
- `/send/external`

Asset-specific routes:

- `/send/payid/{symbol}/{network}`
- `/send/external/{symbol}/{network}`

Behavior on asset-specific send screens:

- Title like `Send Btc`
- Input for destination:
  - `PayID` on internal transfers
  - crypto address field on external transfers
- Amount input
- `Max` action
- percentage shortcuts
- transaction preview section showing:
  - recipient
  - amount
  - transfer fee
  - total amount

Backend implications:

- transfer type
- destination validation
- fee calculation
- balance checks
- transaction status lifecycle

### Receive / Deposit flows

Hub routes:

- `/receive/payid`
- `/receive/external`

Asset-specific routes:

- `/receive/payid/{symbol}/{network}`
- `/receive/external/{symbol}/{network}`

Behavior:

- Title like `Receive Btc`
- Copy and share actions
- external receive page includes exchange/deposit messaging
- receive screen is network-aware

Backend implications:

- PayID generation
- deposit address lookup
- QR/share payload

### Asset detail pages

Examples captured:

- `/crypto/details/usdt/TRC20`
- `/crypto/details/usdt/BNB`
- `/crypto/details/btc/native`

Behavior:

- Shows asset name, network, balance, and fiat value.
- Provides top quick actions:
  - `Send`
  - `Receive`
  - `Buy`
  - `Swap`
- Shows asset-specific transaction history.
- Some routes are passcode-gated again before the detail screen opens.

Backend implications:

- asset-level ledger entries
- quick links into transfer and trade actions
- optional secondary passcode check for sensitive assets/actions

## 3. Admin Application Behavior

### Main navigation

Visible admin sidebar items:

- `Dashboard`
- `Users`
- `KYC Verification`
- `Bots`
- `Subscriptions`
- `Trades`
- `Transactions`
- `General Settings`
- `Email Settings`
- `Wallet Settings`

Confirmed admin routes:

- `/admin/dashboard`
- `/admin/users`
- `/admin/users/create`
- `/admin/users/{id}`
- `/admin/users/{id}/cards`
- `/admin/users/{id}/crypto`
- `/admin/users/{id}/password`
- `/admin/kyc`
- `/admin/kyc?status=pending`
- `/admin/bots`
- `/admin/bots/create`
- `/admin/bots/{id}`
- `/admin/bots/{id}/edit`
- `/admin/subscriptions`
- `/admin/subscriptions/{id}`
- `/admin/trades`
- `/admin/transactions`
- `/admin/settings/general`
- `/admin/settings/email`
- `/admin/settings/wallets`
- `/admin/profile`
- `/admin/2fa/setup`

### Admin dashboard

Route: `/admin/dashboard`

Behavior:

- Metric cards:
  - total users
  - total transactions
  - active cards
  - total crypto value
- Recent transactions table
- Pending KYC panel
- Recent card activities panel

Backend implications:

- dashboard aggregates
- recent transaction feed
- KYC queue
- admin activity timeline

### Users management

Route: `/admin/users`

Behavior:

- Filters:
  - KYC status
  - search by name, email, or ID
- `Create User` action
- User table columns:
  - user
  - KYC status
  - crypto balance
  - register date
  - actions
- Live action area is richer than the current React version.
- Saved HTML exposes embedded admin actions and forms for:
  - manage profile
  - edit crypto addresses
  - wallet phrase
  - delete user
  - update password

Backend implications:

- user CRUD
- KYC filter/search
- admin edit actions from row-level controls

### Create user

Route: `/admin/users/create`

Behavior:

- Fields:
  - name
  - email
  - password
  - passcode
  - require KYC verification
- Primary action is a create-user submit button.

Backend implications:

- admin-provisioned users
- initial passcode storage
- optional KYC requirement flag

### User details

Route: `/admin/users/{id}`

Live result:

- Broken.
- The server throws `View [admin.users.show] not found.` for both `/admin/users/8` and `/admin/users/19`.

Build implication:

- We need to decide whether to:
  - reproduce the live route structure but fix the defect
  - skip the broken show page and route directly to cards/crypto tabs

### User crypto wallet management

Route: `/admin/users/{id}/crypto`

Behavior:

- Shows total balance at top right.
- Renders one card per supported asset/network.
- Each asset card includes:
  - status toggle
  - balance
  - wallet address
  - amount input
  - `Add`
  - `Subtract`

Backend implications:

- per-user asset balances
- per-user wallet addresses
- admin balance adjustment actions
- per-asset enable/disable flag

### User cards management

Route: `/admin/users/{id}/cards`

Behavior:

- Shows existing card visuals.
- Embedded create-card modal/form exists in page HTML.
- Detected fields:
  - card holder name
  - card type
  - expiry month
  - expiry year
  - CVV
  - billing address
  - ZIP code
  - initial balance
- Additional actions:
  - add funds
  - subtract funds
  - activate card
  - delete card

Backend implications:

- user card issuance
- card top-up/deduction
- card lifecycle state

### User password route

Route: `/admin/users/{id}/password`

Live result:

- Broken as a GET page.
- Server returns `The GET method is not supported for route admin/users/{id}/password. Supported methods: PUT.`

Build implication:

- Password change should be a modal or form action, not a direct GET page.

### KYC verification

Route: `/admin/kyc`

Behavior:

- Table columns:
  - user info
  - documents
  - status
  - submitted date
  - actions
- Documents exposed individually:
  - `Front ID`
  - `Back ID`
  - `Proof of Residence`
- Reject flow includes `Rejection Reason`.
- Pending filter route exists: `/admin/kyc?status=pending`

Backend implications:

- KYC queue
- document preview/download
- approve/reject actions with optional reason

### Bots

Routes:

- `/admin/bots`
- `/admin/bots/create`
- `/admin/bots/{id}`
- `/admin/bots/{id}/edit`

Behavior:

- Bots list table columns:
  - bot
  - type
  - status
  - subscriptions
  - investment
  - profit
  - actions
- Create/edit form fields:
  - name
  - bot type
  - min amount
  - max amount
  - duration options
  - supported pairs
  - parameters
  - grid levels
  - upper limit
  - lower limit
- Detail page shows statistics and recent trades.

Backend implications:

- bot definitions
- allowed durations
- supported trading pairs
- parameters blob or structured fields
- subscriptions and trade history

### Subscriptions

Routes:

- `/admin/subscriptions`
- `/admin/subscriptions/{id}`

Behavior:

- List table columns:
  - user/bot
  - amount
  - profit
  - status
  - duration
  - actions
- Detail page shows:
  - user details
  - bot details
  - subscription details
  - trade history table

Backend implications:

- subscription records
- duration and status
- linked trade history

### Trades

Route: `/admin/trades`

Behavior:

- Summary cards:
  - total trades
  - win rate
  - total profit
  - total loss
- Table columns:
  - bot/date
  - trading pair
  - action
  - amount
  - price
  - result
  - profit/loss
  - actions
- Embedded update form/modal fields:
  - result
  - profit amount

Backend implications:

- trade ledger
- admin ability to update result and profit

### Transactions

Route: `/admin/transactions`

Behavior:

- Filters:
  - type
  - status
  - search
- Table columns:
  - user
  - type
  - crypto
  - amount
  - status
  - date
  - actions
- Embedded create transaction form/modal fields:
  - user
  - transaction type
  - cryptocurrency
  - from crypto
  - to crypto
  - amount in
  - amount out
  - network fee
  - rate
- Embedded approval and rejection actions exist.

Backend implications:

- transaction CRUD
- approval workflow
- multi-asset swap fields
- search by transaction hash/address

### Settings

General settings route: `/admin/settings/general`

- Company information
- site logo
- site favicon
- referral system toggle
- referral bonus amount
- bonus distribution

Email settings route: `/admin/settings/email`

- SMTP configuration fields
- sender identity
- email header logo
- notification toggles:
  - user registration
  - KYC submission
  - KYC approval

Wallet settings route: `/admin/settings/wallets`

- Global wallet address fields for all supported assets/networks

Backend implications:

- app settings table
- SMTP/env-backed settings
- wallet address registry
- referral configuration

### Admin profile

Route: `/admin/profile`

Behavior:

- Profile information form:
  - name
  - email
- Password update form:
  - current password
  - new password
  - confirm password

### Admin 2FA

Route: `/admin/2fa/setup`

Behavior:

- Shows current 2FA status.
- Shows QR code.
- Shows manual secret.
- Accepts verification code.
- Exposes recovery codes.
- Includes disable 2FA flow.

Backend implications:

- TOTP secret storage
- provisioning QR
- recovery codes
- enable/disable verification

## 4. Live Defects and Oddities

These were observed on the live system and should be treated as explicit decisions during rebuild:

- `/admin/users/{id}` is broken because the Blade view is missing.
- `/admin/users/{id}/password` is linked like a page but only accepts `PUT`.
- `/crypto/details/btc/native` triggers a second passcode screen that did not auto-clear during scripted navigation.
- The verified user KYC page still contains upload form HTML for the unverified state, so the UI appears state-switched rather than route-switched.

## 5. Gap Map Against the Current React App

Current route reference: `qfs-wallet/src/App.tsx`

What already exists in React:

- user dashboard and major user pages
- admin dashboard, users, KYC, bots, subscriptions, trades, transactions, settings, profile, 2FA

What is still structurally missing or mismatched:

- No passcode page or two-step login flow.
- User app is mounted under `/app/*`, while the live system uses direct root routes like `/dashboard` and `/settings`.
- Missing user send/receive route family:
  - `/send/payid`
  - `/send/external`
  - `/receive/payid`
  - `/receive/external`
  - asset-specific send/receive pages
- Missing user asset detail route family:
  - `/crypto/details/{symbol}/{network}`
- Admin 2FA route mismatch:
  - current React route is `/admin/2fa`
  - live route is `/admin/2fa/setup`
- Current `AdminUsersPage.tsx` is simpler than the live system and does not expose the row-level modal/action set seen in live HTML.
- Current `AdminUserRecordsPage.tsx` is a summary table page, while the live system uses operational wallet cards with add/subtract controls and full card-management modals.
- Current `AdminTransactionsPage.tsx` lacks the live filters, create-transaction form, and approve/reject workflow.
- Current `AdminBotFormPage.tsx` uses a different data model than the live bot form, which is closer to:
  - bot type
  - min/max amount
  - duration options
  - supported pairs
  - grid parameters
- Current `AdminSettingsPage.tsx` is a simplified frontend representation and does not yet match the live forms for SMTP, referral config, and global wallet addresses.

## 6. Backend Domain Model We Need

Minimum backend entities inferred from the live product:

- users
- roles
- sessions
- passcodes
- kyc submissions
- kyc documents
- crypto assets
- crypto networks
- user wallets
- wallet addresses
- wallet transactions
- cards
- card transactions
- bots
- bot subscriptions
- trades
- notifications
- referrals
- settings
- audit logs

## 7. Recommended Build Order

1. Implement auth and passcode flow first.
2. Align routing to live route structure.
3. Build user ledger features:
   - dashboard
   - asset detail
   - send
   - receive
   - swap
4. Build admin operational tools:
   - users
   - user crypto
   - user cards
   - transactions
   - trades
   - KYC
5. Build settings and SMTP integration.
6. Add notifications, referrals, and bot subscription polish.
7. Decide explicitly which live defects are fixed instead of cloned.

## 8. Immediate Next Decisions

Before implementation, we should lock these choices:

- keep live route paths exactly, or keep `/app/*` and remap only the visible navigation
- reproduce the live second passcode gate on sensitive routes, or simplify to one passcode check after login
- fix the broken admin show/password routes during rebuild, or keep only the working cards/crypto actions
- use SQLite-first backend schema now, but keep migrations MySQL-compatible for later migration
