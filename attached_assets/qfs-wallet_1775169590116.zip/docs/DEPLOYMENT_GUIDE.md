# Deployment Guides: aaPanel & cPanel Shared Hosting

Since you are utilizing control panels and graphic interfaces, you do not need to rely heavily on the command line! Below are two tailored, step-by-step guides for deploying your React + Node.js (Vite) application depending on which control panel you use.

---

## Guide 1: Deploying via aaPanel (with Apache)

aaPanel makes Node.js deployments incredible easy, even if you are using Apache instead of Nginx as your web server. aaPanel configures the Apache reverse proxy rules automatically.

### Step 1: Prepare and Upload Files
1. On your local machine, run `npm run build` in your terminal to ensure your `dist/` folder is updated and compiled.
2. Log into aaPanel and go to **Files**.
3. Navigate to `/www/wwwroot/` and create a folder named `qfs-wallet`.
4. Upload all of your project files (including the `dist` folder, `server`, `src`, `package.json`, etc.) into `/www/wwwroot/qfs-wallet`. Note: You do not need to upload `node_modules`.

### Step 2: Database Configuration
1. Go to the **Databases** tab on the left sidebar.
2. Click **Add Database**.
3. Name it `qfs_wallet` and let it auto-generate a username and strong password. Click submit.
4. If you have exported a `.sql` file from your local XAMPP setup, click **Import** next to your new database to upload your tables.
5. In the **Files** menu, open the `.env` file in your `qfs-wallet` folder and update `DB_USER` and `DB_PASSWORD` to the credentials aaPanel just gave you.

### Step 3: Launching the Node Project
aaPanel has a built in Node version manager that acts as PM2.
1. Go to **Website** on the left sidebar, then click the **Node project** tab at the top.
2. Click **Add Node project**.
3. Fill out the configuration form:
   - **Path:** Click the folder icon and select `/www/wwwroot/qfs-wallet`
   - **Name:** `qfs-wallet`
   - **Run opt:** Once the path is selected, it will read `package.json`. Select `start` from the dropdown list.
   - **Port:** `4000` (must match `API_PORT` in your `.env`)
   - **User:** `www`
   - **Node:** `v24.14.1` (or whatever LTS version you have installed)
   - **Domain name:** Enter your live domain name (e.g., `yourdomain.com`).
4. Click **Confirm**. 

> [!TIP]
> aaPanel will now automatically run `npm install`, start your app in the background, and configure **Apache** to instantly proxy traffic from your domain name to port 4000. 

### Step 4: Add SSL (HTTPS)
1. In the **Node project** list, click **Conf** (or Settings) next to your newly created site.
2. Go to the **SSL** tab.
3. Select **Let's Encrypt**, check your domain name, and click Apply. Your site is now live securely!

---

## Guide 2: Deploying via cPanel (Shared Hosting)

Most modern cPanel shared hosting providers use CloudLinux and a module called "Phusion Passenger" to run Node.js apps. 

### Step 1: Upload Files to cPanel
1. Locally, run `npm run build`.
2. Zip your entire project folder (exclude `node_modules` to save upload time).
3. Log into cPanel and open the **File Manager**.
4. It's best practice to put Node apps *outside* of `public_html`. Create a folder in your root directory (e.g., `/home/username/qfs-wallet`).
5. Upload the ZIP file into this folder and extract it.

### Step 2: Database Setup
1. In cPanel, go to **MySQL® Databases**.
2. Create a new database (e.g., `username_qfswallet`).
3. Create a new User and generate a strong password.
4. Add the User to the Database, and check "All Privileges".
5. Go back to File Manager, edit your `.env` file, and update your `DB_NAME`, `DB_USER`, and `DB_PASSWORD` to match what cPanel generated.

### Step 3: Setup Node.js App in cPanel
1. Go back to the main cPanel dashboard.
2. Scroll to the **Software** section and click **Setup Node.js App**. 
   *(Note: If you don't see this icon, your shared hosting plan does not support Node.js. You must ask your host to enable it or switch to a VPS like aaPanel).*
3. Click **Create Application**.
4. Fill out the application form:
   - **Node.js Version:** Select the newest available (e.g., 18.x or 20.x).
   - **Application mode:** Production
   - **Application root:** `qfs-wallet` (the folder you created in Step 1).
   - **Application URL:** Choose your domain from the dropdown. Leave the box next to it blank to run on the main domain.
   - **Application startup file:** `server/index.mjs`
5. Click **Create**.

### Step 4: Install Dependencies & Start
1. After the app is created, cPanel will keep you on an overview page for this specific app.
2. Scroll down to the **Modules** section or look for a button that says **Run NPM Install** and click it. Wait for it to finish installing dependencies successfully.
3. Once it finishes, scroll to the top of the page and click the **Restart** button.

> [!NOTE]
> In cPanel shared hosting, you **do not** specify a port like 4000 in your Node.js code because Phusion Passenger intercepts the traffic automatically through a dynamically assigned pipe. Your `.env` setting for `API_PORT` is usually ignored by the cPanel runtime mechanism natively.

Your app will now be live on your cPanel domain!
